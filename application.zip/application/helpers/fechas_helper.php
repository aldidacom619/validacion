<?php
/**
 * Created by PhpStorm.
 * User: framos
 * Date: 3/8/2017
 * Time: 3:00 PM
 */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function getCurrentYear()
{
//    return date("Y");
    return 2016;
}